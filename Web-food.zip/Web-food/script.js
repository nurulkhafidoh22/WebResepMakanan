document.addEventListener('DOMContentLoaded', () => {
    const menuIcon = document.querySelector('#menu-icon');
    const navbar = document.querySelector('.navbar');
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('header nav a');

    // Scroll detection and active link update
    window.addEventListener('scroll', () => {
        let scrollPosition = window.scrollY;

        sections.forEach(sec => {
            const sectionOffset = sec.offsetTop - 150;
            const sectionHeight = sec.offsetHeight;
            const sectionId = sec.getAttribute('id');

            if (scrollPosition >= sectionOffset && scrollPosition < sectionOffset + sectionHeight) {
                navLinks.forEach(link => {
                    link.classList.remove('active');
                });
                const activeLink = document.querySelector(`header nav a[href="#${sectionId}"]`);
                if (activeLink) {
                    activeLink.classList.add('active');
                }
            }
        });
    });

    // Menu icon functionality for mobile navbar
    menuIcon.addEventListener('click', () => {
        menuIcon.classList.toggle('bx-x'); // Change icon when menu is active
        navbar.classList.toggle('active'); // Toggle navbar display
    });

    // Service worker registration
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/service-worker.js')
                .then(reg => console.log('Service Worker Registered', reg))
                .catch(err => console.error('Service Worker registration failed', err));
        });
    }
});

// Install prompt handling (PWA install)
let deferredPrompt;
const installButton = document.getElementById('install-button'); // Element for install button

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();  // Prevent the default mini-info bar from appearing
    deferredPrompt = e;  // Save the event

    // Show the install button
    if (installButton) {
        installButton.style.display = 'block';

        installButton.addEventListener('click', () => {
            // Show the install prompt
            deferredPrompt.prompt();

            // Wait for the user to respond to the prompt
            deferredPrompt.userChoice.then((choiceResult) => {
                if (choiceResult.outcome === 'accepted') {
                    console.log('User accepted the install prompt');
                } else {
                    console.log('User dismissed the install prompt');
                }
                deferredPrompt = null;
            });
        });
    }
});

// Hide install button after installation
window.addEventListener('appinstalled', () => {
    console.log('PWA has been installed');
    if (installButton) {
        installButton.style.display = 'none'; // Hide the install button after installation
    }
});

// Function for searching and filtering content on the page based on keywords.
function searchFood() {
    const searchInput = document.getElementById('search-input').value.toLowerCase().trim();
    const foodItems = document.querySelectorAll('.food-box');
    
    // Check if there's a keyword entered
    if (searchInput === "") {
        // Show all items if search box is empty
        foodItems.forEach(item => {
            item.style.display = 'block';
        });
    } else {
        // Show only items matching the keyword
        foodItems.forEach(item => {
            const foodName = item.querySelector('h1').textContent.toLowerCase();
            
            if (foodName.includes(searchInput)) {
                item.style.display = 'block';  // Show item if matched
            } else {
                item.style.display = 'none';   // Hide item if not matched
            }
        });
    }
    
    return false; // Prevent form submit and page reload
}
