// Nama cache dengan versi untuk cache statis
const CACHE_NAME = 'cooking-v2';
const urlsToCache = [
    '/',  // Halaman utama
    '/index.html',  // File HTML
    '/style.css',  // File CSS
    '/script.js',  // File JavaScript
    '/manifest.json',  // File manifest (jika ada)
    '/images/Background-1.jpg',  // Gambar lainnya
    '/images/nasi-goreng.jpg',
    '/images/bumbu.jpg',
    '/images/rendang.jpg',
    '/images/ayam-penyet.jpg',
    '/images/sop-buntut.jpg',
    '/images/ikan-bakar.jpg',
    '/images/sate-ayam.jpg',
    '/images/icon-192x192.png',
    '/images/mie-goreng.jpg',
    '/images/gado-gado.jpg',
    '/images/pisang-goreng.jpg',
    '/images/cumi-saus-padang.jpg',
    '/images/ayam-geprek.jpg',
    '/images/soto-ayam.jpg',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css',
    'https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css',
    'https://unpkg.com/boxicons@2.1.4/fonts/boxicons.woff2',
    'https://unpkg.com/boxicons@2.1.4/fonts/boxicons.woff',
    'https://unpkg.com/boxicons@2.1.4/fonts/boxicons.ttf'
    // Tambahkan resource lainnya jika ada
];

// Install event - caching file statis
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Membuka cache:', CACHE_NAME);
                return cache.addAll(urlsToCache);  // Cache semua file yang telah didefinisikan
            })
            .catch(error => {
                console.error('Cache gagal dibuka: ', error);
            })
    );
});

// Activate event - menghapus cache lama
self.addEventListener('activate', event => {
    const cacheWhitelist = [CACHE_NAME];  // Cache yang diizinkan

    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheWhitelist.indexOf(cacheName) === -1) {
                        console.log('Menghapus cache lama:', cacheName);
                        return caches.delete(cacheName);  // Menghapus cache yang tidak diizinkan
                    }
                })
            );
        })
    );
    self.clients.claim();  // Membuat service worker aktif segera
});

// Fetch event - menggunakan pola Cache Only
self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request)
            .then(cachedResponse => {
                if (cachedResponse) {
                    // Kembalikan dari cache jika ada
                    return cachedResponse;
                } else {
                    // Mengembalikan respons 404 jika tidak ada di cache
                    return new Response('Resource not found in cache', { status: 404 });
                }
            })
            .catch(error => {
                console.error('Error retrieving from cache:', error);
                // Mengembalikan respons 500 jika terjadi kesalahan
                return new Response('Error retrieving resource', { status: 500 });
            })
    );
});